***ScaMot
